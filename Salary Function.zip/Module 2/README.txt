
  -------- Instructions on how to Read the files--------------


i) Please run the file saved as "SalaryFunction" using Jupyter notebook or VS Code.
ii) Please run the file saved as "R Code used to Unzip" to unzipped the zipped files from a specific folder to a specified folder path.

The project have been saved in Github repository under the path: https://github.com/Chirchirp/Salary-Function
